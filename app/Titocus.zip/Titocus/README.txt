Titocus App

Thank you for using the Titocus App! This app was created as part of a school project.

How to Launch the App on macOS
------------------------------
Since this app is not signed with an Apple Developer certificate, macOS will show a warning the first time you try to open it.

To run the app:

1. Right-click (or Control-click) the 'Titocus.app' file.
2. Select "Open" from the menu.
3. In the warning dialog, click "Open Anyway" again.
4. You will then be prompted to enter your device password to confirm.

If the warning dialog does not appear:

1. Go to System Settings > Privacy & Security.
2. Scroll down to the Security section.
3. Click on "Open Anyway" next to the message about Titocus.app being blocked.
4. A new dialog will appear – click "Open Anyway" again.
5. You will then be prompted to enter your device password to confirm.

In both cases, macOS will remember your choice, and the app will launch normally after that.

Disclaimer
----------
This version of the app is intended for educational use only. It is not notarised or distributed through the App Store.